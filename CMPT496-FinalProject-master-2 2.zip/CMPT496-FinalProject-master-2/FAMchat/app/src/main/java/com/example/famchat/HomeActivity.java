package com.example.famchat;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import androidx.core.app.ActivityCompat;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Location;
import android.nfc.Tag;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;

import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

import java.util.Calendar;
import java.util.Date;

public class HomeActivity extends AppCompatActivity {

    CardView SendRequestsButton;
    CardView ViewRequestsButton;
    CardView viewMapsButton;
    CardView StatusRequestsButton;
    CardView viewEmButton;
    CardView SendEmergencyButton;
    ImageView Settings;

    String loctime;
    Location currentLocation;
    FusedLocationProviderClient fusedLocationProviderClient;

    Locations loc;

    private static final int REQUEST_CODE = 101;

    DatabaseReference databaseReference;
    DatabaseReference datab;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        fusedLocationProviderClient = LocationServices.getFusedLocationProviderClient(this);

        if(ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED){
            ActivityCompat.requestPermissions(this, new String[]
                    {Manifest.permission.ACCESS_FINE_LOCATION}, REQUEST_CODE);
            return;
        }
        loc = new Locations();
        fusedLocationProviderClient.getLastLocation()
                .addOnSuccessListener(this, new OnSuccessListener<Location>() {
                    @Override
                    public void onSuccess(Location location) {
                        if(location!=null){
                            currentLocation = location;
                            final String newemail = GlobalVariable.CurrentEmail.replace(".",",");
                            Date curtime = Calendar.getInstance().getTime();
                            loctime = curtime.toString();
                            databaseReference = FirebaseDatabase.getInstance().getReference();
                            databaseReference.child("Users").child(newemail).child("latitude").setValue(currentLocation.getLatitude());
                            databaseReference.child("Users").child(newemail).child("longitude").setValue(currentLocation.getLongitude());
                            databaseReference.child("Users").child(newemail).child("locTime").setValue(loctime);
                            loc.setLatitude(currentLocation.getLatitude());
                            loc.setLongtitude(currentLocation.getLongitude());
                            loc.setTime(loctime);
                            databaseReference.child("Locations").child(newemail).push().setValue(loc);

                            databaseReference = FirebaseDatabase.getInstance().getReference().child("Locations").child(newemail);
                            databaseReference.addListenerForSingleValueEvent(new ValueEventListener() {
                                @Override
                                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                                    int size = (int) dataSnapshot.getChildrenCount();
                                    if(size == 11){
                                        datab = FirebaseDatabase.getInstance().getReference().child("Locations").child(newemail);
                                        Query query = datab.limitToFirst(1);
                                        query.addListenerForSingleValueEvent(new ValueEventListener() {
                                            @Override
                                            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                                                for(DataSnapshot childSnapshot : dataSnapshot.getChildren()){
                                                    childSnapshot.getRef().removeValue();
                                                }
                                            }

                                            @Override
                                            public void onCancelled(@NonNull DatabaseError databaseError) {

                                            }
                                        });
                                    }
                                }

                                @Override
                                public void onCancelled(@NonNull DatabaseError databaseError) {

                                }
                            });

                        }
                    }
                });

        AlarmHandler alarmHandler = new AlarmHandler(this);

        alarmHandler.cancelAlarmManager();

        alarmHandler.setAlarmManager();




        SendRequestsButton = (CardView) findViewById(R.id.SendRequestsButton);
        ViewRequestsButton = (CardView) findViewById(R.id.ViewRequestsButton);
        viewMapsButton = (CardView) findViewById(R.id.viewMapsButton);
        StatusRequestsButton = (CardView) findViewById(R.id.StatusRequestsButton);
        viewEmButton = (CardView) findViewById(R.id.viewEmButton);
        SendEmergencyButton = (CardView) findViewById(R.id.SendEmergencyButton);
        Settings = (ImageView) findViewById(R.id.Settings);


        SendRequestsButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(HomeActivity.this, SendUpdateRequestsActivity.class);
                startActivity(intent);
            }
        });

        viewMapsButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(HomeActivity.this, MapsActivity.class);
                startActivity(intent);

            }
        });

        ViewRequestsButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(HomeActivity.this, ViewRequests.class);
                startActivity(intent);
            }
        });

        StatusRequestsButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(HomeActivity.this, StatusRequests.class);
                startActivity(intent);
            }
        });

        viewEmButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(HomeActivity.this, ViewEmergencies.class);
                startActivity(intent);
            }
        });

        SendEmergencyButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(HomeActivity.this, SendEmergency.class);
                startActivity(intent);
            }
        });

        Settings.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(HomeActivity.this, SettingsActivity.class);
                startActivity(intent);
            }
        });



    }
}
