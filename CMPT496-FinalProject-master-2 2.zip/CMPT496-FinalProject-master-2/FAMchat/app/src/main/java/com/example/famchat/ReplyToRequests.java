package com.example.famchat;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.Calendar;
import java.util.Date;

public class ReplyToRequests extends AppCompatActivity {

    TextView from2;
    TextView from3;
    EditText Code;
    Button ReplyButton;
    Requests request;
    Users user;

    DatabaseReference Reff;
    DatabaseReference datab;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_reply_to_requests);

        from2 = (TextView) findViewById(R.id.from2);
        from3 = (TextView) findViewById(R.id.from3);
        ReplyButton = (Button) findViewById(R.id.ReplyButton);
        Code = (EditText) findViewById(R.id.Code);

        from2.setText(GlobalVariable.FromEmail);
        from3.setText(GlobalVariable.Message);

        ReplyButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                checkCode();
            }
        });
    }

    public void checkCode(){
        final String EnteredCode = Code.getText().toString().trim().toLowerCase();
        final String ActualSafeCode = GlobalVariable.SafeCode.trim().toLowerCase();

        if (ActualSafeCode.equals(EnteredCode)){
            String Message = "Your Update Request to " + GlobalVariable.CurrentEmail + " has been replied with the safe code";
            String Sendto = GlobalVariable.FromEmail.replace(".", ",");
            Date curtime = Calendar.getInstance().getTime();
            String Time = curtime.toString().substring(0,20);

            request = new Requests();
            request.setMessage(Message);
            request.setTime(Time);
            request.setSenderEmail(GlobalVariable.CurrentEmail);

            Reff = FirebaseDatabase.getInstance().getReference();
            Reff.child("Requests").child(GlobalVariable.CurrentEmail.replace(".",",")).removeValue();

            Reff = FirebaseDatabase.getInstance().getReference();
            Reff.child("View Sent Requests").child(Sendto).push().setValue(request);

        }else {
            String Message = "Your Update Request to " + GlobalVariable.CurrentEmail + " has been replied with the Emergency Code. Check Emergency Tab for Further Details.";
            String Sendto = GlobalVariable.FromEmail.replace(".", ",");
            Date curtime = Calendar.getInstance().getTime();
            String Time = curtime.toString().substring(0, 20);

            request = new Requests();
            request.setMessage(Message);
            request.setTime(Time);
            request.setSenderEmail(GlobalVariable.CurrentEmail);

            Reff = FirebaseDatabase.getInstance().getReference();
            Reff.child("View Sent Requests").child(Sendto).push().setValue(request);

            Reff = FirebaseDatabase.getInstance().getReference();
            Reff.child("Requests").child(GlobalVariable.CurrentEmail.replace(".",",")).removeValue();

            Reff = FirebaseDatabase.getInstance().getReference().child("Users");
            Reff.addListenerForSingleValueEvent(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                    for(DataSnapshot snapshot : dataSnapshot.getChildren()){
                        user = snapshot.getValue(Users.class);

                        if(user.getGroupID().equals(GlobalVariable.CurrentGroupID)){
                            if(user.getEmail().equals(GlobalVariable.CurrentEmail)){

                            }else{
                                request.setMessage("Emergency Reported");
                                datab = FirebaseDatabase.getInstance().getReference();
                                datab.child("Emergencies").child(user.getEmail().replace(".", ",")).push().setValue(request);
                            }
                        }
                    }
                }

                @Override
                public void onCancelled(@NonNull DatabaseError databaseError) {

                }
            });
        }

        Toast.makeText(ReplyToRequests.this, "Successfully replied", Toast.LENGTH_LONG).show(); 
        Intent intent = new Intent(this, HomeActivity.class); //Switch to reply to request
        startActivity(intent);
        finish();


    }
}
