package com.example.famchat;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;


public class StatusRequests extends AppCompatActivity {

    DatabaseReference Reff;
    ListView StatusView;
    ArrayList<String> statuslist;
    ArrayAdapter<String> arrayAdapter;

    Requests request;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_status_requests);

        statuslist = new ArrayList<>();
        String email = GlobalVariable.CurrentEmail.replace(".", ",").trim();
        Reff = FirebaseDatabase.getInstance().getReference().child("View Sent Requests").child(email);
        StatusView = (ListView) findViewById(R.id.StatusView);
        arrayAdapter = new ArrayAdapter<String>(StatusRequests.this, R.layout.row, statuslist);
        StatusView.setAdapter(arrayAdapter);

        Reff.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                for (DataSnapshot snapshot : dataSnapshot.getChildren()){
                    request = snapshot.getValue(Requests.class);
                    statuslist.add(request.toString());
                }
                StatusView.setAdapter(arrayAdapter);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });


    }
}
