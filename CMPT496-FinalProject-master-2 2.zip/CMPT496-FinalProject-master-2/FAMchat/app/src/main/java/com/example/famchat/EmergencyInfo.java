package com.example.famchat;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.google.firebase.database.DatabaseReference;

import org.w3c.dom.Text;

public class EmergencyInfo extends AppCompatActivity {

    TextView EmFrom;
    TextView EmMessage;
    Button ViewLocationsButton;
    Requests request;
    Users user;

    DatabaseReference Reff;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_emergency_info);

        EmFrom = (TextView) findViewById(R.id.EmFrom);
        EmMessage = (TextView) findViewById(R.id.EmMessage);
        ViewLocationsButton = (Button) findViewById(R.id.ViewLocationsButton);

        EmFrom.setText(GlobalVariable.FromEmail);
        EmMessage.setText(GlobalVariable.Message);

        ViewLocationsButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(EmergencyInfo.this, ViewLocationHistory.class); //Switch to reply to request
                startActivity(intent);
            }
        });



    }
}
