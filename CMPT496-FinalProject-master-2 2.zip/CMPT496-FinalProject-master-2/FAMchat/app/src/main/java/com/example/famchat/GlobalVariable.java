package com.example.famchat;

public class GlobalVariable {
    public static String CurrentEmail;
    public static String CurrentGroupID;
    public static String CurrentName;
    public static String SendEmail;
    public static String Time;
    public static String FromEmail;
    public static String Message;
    public static String SafeCode;
    public static String MemberStatus;
    public static String Name;
    public static String ClickedMemeberStatus;
    public static String ClickedMemberEmail;
}
