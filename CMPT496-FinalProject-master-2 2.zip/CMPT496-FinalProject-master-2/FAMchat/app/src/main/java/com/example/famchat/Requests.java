package com.example.famchat;

public class Requests {
    private String SenderEmail;
    private String Message;
    private String Time;

    public Requests(){

    }

    public String getSenderEmail() {
        return SenderEmail;
    }

    public void setSenderEmail(String senderEmail) {
        SenderEmail = senderEmail;
    }

    public String getMessage() {
        return Message;
    }

    public void setMessage(String message) {
        Message = message;
    }

    public String getTime() {
        return Time;
    }

    public void setTime(String time) {
        Time = time;
    }

    public String toString(){
        return this.SenderEmail + " - " + this.Time + "\n" + this.Message;
    }
}
