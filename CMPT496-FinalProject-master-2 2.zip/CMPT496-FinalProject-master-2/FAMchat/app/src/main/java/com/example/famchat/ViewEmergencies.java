package com.example.famchat;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class ViewEmergencies extends AppCompatActivity {

    DatabaseReference Reff;
    ListView EMView;
    ArrayList<String> EmList;
    ArrayAdapter<String> arrayAdapter;

    Requests request;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_emergencies);

        EmList = new ArrayList<>();
        String email = GlobalVariable.CurrentEmail.replace(".", ",").trim();
        Reff = FirebaseDatabase.getInstance().getReference().child("Emergencies").child(email);
        EMView = (ListView) findViewById(R.id.EMView);
        arrayAdapter = new ArrayAdapter<String>(ViewEmergencies.this, R.layout.row, EmList);
        EMView.setAdapter(arrayAdapter);

        Reff.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                EmList.clear();
                for (DataSnapshot snapshot : dataSnapshot.getChildren()){
                    request = snapshot.getValue(Requests.class);
                    EmList.add(request.toString());
                }
                EMView.setAdapter(arrayAdapter);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });

        EMView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                GlobalVariable.FromEmail = (String) EMView.getItemAtPosition(position);
                GlobalVariable.FromEmail = GlobalVariable.FromEmail.split("-")[0].trim();
                GlobalVariable.Message = (String) EMView.getItemAtPosition(position);
                GlobalVariable.Message = GlobalVariable.Message.split("\n")[1];
                Intent intent = new Intent(ViewEmergencies.this, EmergencyInfo.class); //Switch to reply to request
                startActivity(intent);
            }
        });

    }
}
