package com.example.famchat;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.AdapterView;
import android.widget.ListView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class ViewRequests extends AppCompatActivity {

    DatabaseReference Reff;
    ListView RequestView;
    ArrayList<String> RequestList;
    ArrayAdapter<String> arrayAdapter;

    Requests request;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_requests);

        RequestList = new ArrayList<>();
        String email = GlobalVariable.CurrentEmail.replace(".", ",").trim();
        Reff = FirebaseDatabase.getInstance().getReference().child("Requests").child(email);
        RequestView = (ListView) findViewById(R.id.RequestView);
        arrayAdapter = new ArrayAdapter<String>(ViewRequests.this, R.layout.row, RequestList);
        RequestView.setAdapter(arrayAdapter);

        Reff.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                RequestList.clear();
                for (DataSnapshot snapshot : dataSnapshot.getChildren()){
                    request = snapshot.getValue(Requests.class);
                    RequestList.add(request.toString());
                }
                RequestView.setAdapter(arrayAdapter);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });

        RequestView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                GlobalVariable.FromEmail = (String) RequestView.getItemAtPosition(position);
                GlobalVariable.FromEmail = GlobalVariable.FromEmail.split("-")[0].trim();
                GlobalVariable.Message = (String) RequestView.getItemAtPosition(position);
                GlobalVariable.Message = GlobalVariable.Message.split("\n")[1];
                Intent intent = new Intent(ViewRequests.this, ReplyToRequests.class); //Switch to reply to request
                startActivity(intent);
            }
        });
    }


}
