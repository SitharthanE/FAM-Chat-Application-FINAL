package com.example.famchat;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.common.api.internal.IStatusCallback;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class SettingsActivity extends AppCompatActivity {

    DatabaseReference datab;
    DatabaseReference reff;
    ListView Others;
    TextView CurrentInfo;
    ArrayList<String> memberlist;
    ArrayAdapter<String> arrayAdapter;
    Users user;
    Users stat;
    String Email;
    String Name;
    String Status;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);

        CurrentInfo = (TextView) findViewById(R.id.CurrentInfo);
        memberlist = new ArrayList<>();
        datab = FirebaseDatabase.getInstance().getReference().child("Users");
        Others = (ListView) findViewById(R.id.Others);
        arrayAdapter = new ArrayAdapter<String>(SettingsActivity.this, R.layout.row, memberlist);
        Others.setAdapter(arrayAdapter);

        reff = FirebaseDatabase.getInstance().getReference().child("Users");
        reff.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                for (DataSnapshot snapshot: dataSnapshot.getChildren()){
                    stat = snapshot.getValue(Users.class);

                    if(stat.getEmail().equals(GlobalVariable.CurrentEmail)){
                        GlobalVariable.MemberStatus = stat.getStatus();
                    }
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });



        CurrentInfo.setText(GlobalVariable.CurrentName + "\n" + GlobalVariable.CurrentEmail + "\n" + GlobalVariable.MemberStatus);




        datab.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                memberlist.clear();
                for (DataSnapshot snapshot : dataSnapshot.getChildren()){
                    user = snapshot.getValue(Users.class);

                    if ((user.getGroupID().equals(GlobalVariable.CurrentGroupID))){
                        if (user.getEmail().equals(GlobalVariable.CurrentEmail)){

                        }else{
                            memberlist.add(user.toString() + "\n" + user.getStatus().toString());
                        }
                    }
                }
                Others.setAdapter(arrayAdapter);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });

        if(GlobalVariable.MemberStatus.equals("Leader")){
            Others.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                @Override
                public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                    Email = (String) Others.getItemAtPosition(position);
                    Email = Email.split("\n")[0];
                    GlobalVariable.ClickedMemberEmail = Email.trim();
                    Status = (String) Others.getItemAtPosition(position);
                    Status = Status.substring(Status.lastIndexOf("\n"));
                    Status = Status.trim();
                    GlobalVariable.ClickedMemeberStatus = Status;

                    Intent intent = new Intent(SettingsActivity.this, MakeLeader.class);
                    startActivity(intent);

                }
            });
        }
    }
}
