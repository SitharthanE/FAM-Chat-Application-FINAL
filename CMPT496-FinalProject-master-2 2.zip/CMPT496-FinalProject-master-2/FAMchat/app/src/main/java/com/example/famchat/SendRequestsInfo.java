package com.example.famchat;

import androidx.appcompat.app.AppCompatActivity;

import android.app.DownloadManager;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.Calendar;
import java.util.Date;

public class SendRequestsInfo extends AppCompatActivity {

    Button sendRequestsButton;
    EditText emailEntry;

    DatabaseReference Reff;

    Users user;

    Requests request;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_send_requests_info);

        sendRequestsButton = (Button) findViewById(R.id.sendRequestsButton);
        emailEntry = (EditText) findViewById(R.id.emailEntry);

        sendRequestsButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sendRequest();

            }
        });
    }

    public void sendRequest() {
        final String Message = emailEntry.getText().toString().trim();
        final String SendTo = GlobalVariable.SendEmail.replace(".", ",");
        final String From = GlobalVariable.CurrentEmail;

        request = new Requests();
        Toast.makeText(SendRequestsInfo.this, "Request Sent Successfully", Toast.LENGTH_LONG).show();

        Date curtime = Calendar.getInstance().getTime();
        final String Time = curtime.toString().substring(0,20);

        request.setMessage(Message);
        request.setSenderEmail(From);
        request.setTime(Time);

        Reff = FirebaseDatabase.getInstance().getReference();
        Reff.child("Requests").child(SendTo).push().setValue(request); //Push request to the database

        Intent intent = new Intent(SendRequestsInfo.this, SendUpdateRequestsActivity.class);
        startActivity(intent);
        finish();


    }
}
