package com.example.famchat;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class MakeLeader extends AppCompatActivity {

    Button ViewHist;
    Button MakeL;
    DatabaseReference datab;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_make_leader);

        ViewHist = (Button) findViewById(R.id.ViewHist);
        MakeL = (Button) findViewById(R.id.MakeL);

        MakeL.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(GlobalVariable.ClickedMemeberStatus.equals("Leader")){
                    Toast.makeText(MakeLeader.this, "This member is already a Leader" , Toast.LENGTH_LONG).show();
                }else{
                    datab = FirebaseDatabase.getInstance().getReference();
                    datab.child("Users").child(GlobalVariable.ClickedMemberEmail.replace(".", ",")).child("status").setValue("Leader");
                    Toast.makeText(MakeLeader.this, "This member has been promoted to Leader" , Toast.LENGTH_LONG).show();
                }
            }
        });

        ViewHist.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                GlobalVariable.FromEmail = GlobalVariable.ClickedMemberEmail;

                Intent intent = new Intent(MakeLeader.this, ViewLocationHistory.class);
                startActivity(intent);
            }
        });


    }
}
