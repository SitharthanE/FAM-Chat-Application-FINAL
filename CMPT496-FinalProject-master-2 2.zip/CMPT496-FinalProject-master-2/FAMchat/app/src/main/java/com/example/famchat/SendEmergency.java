package com.example.famchat;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.Calendar;
import java.util.Date;

public class SendEmergency extends AppCompatActivity {

    TextView EmergencyMsg;
    Button SendEmButton;

    Requests request;

    DatabaseReference Reff;

    Users user;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_send_emergency);

        SendEmButton = (Button) findViewById(R.id.SendEmButton);
        EmergencyMsg = (TextView) findViewById(R.id.EmergencyMsg);

        SendEmButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                SendEm();
            }
        });

    }

    public void SendEm(){

        Date curtime = Calendar.getInstance().getTime();
        String Time = curtime.toString().substring(0, 20);

        request = new Requests();
        request.setMessage(EmergencyMsg.getText().toString());
        request.setSenderEmail(GlobalVariable.CurrentEmail);
        request.setTime(Time);

        Reff = FirebaseDatabase.getInstance().getReference().child("Users");
        Reff.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                for(DataSnapshot snapshot : dataSnapshot.getChildren()){
                    user = snapshot.getValue(Users.class);

                    if(user.getGroupID().equals(GlobalVariable.CurrentGroupID)){
                        if(user.getEmail().equals(GlobalVariable.CurrentEmail)){

                        }else{
                            Reff = FirebaseDatabase.getInstance().getReference();
                            Reff.child("Emergencies").child(user.getEmail().replace(".", ",")).push().setValue(request);


                        }
                    }
                }

            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });

        Intent intent = new Intent(SendEmergency.this, HomeActivity.class);
        startActivity(intent);
        finish();
    }
}
