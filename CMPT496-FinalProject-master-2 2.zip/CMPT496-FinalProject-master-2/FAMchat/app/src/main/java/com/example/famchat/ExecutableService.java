package com.example.famchat;

import android.Manifest;
import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Location;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.core.app.ActivityCompat;

import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

import java.util.Calendar;
import java.util.Date;
import java.util.concurrent.Executor;

public class ExecutableService extends BroadcastReceiver {

    String locTime;
    Location latestLoc;
    FusedLocationProviderClient fusedLocationProviderClient;
    Context context;

    DatabaseReference databaseReference;
    DatabaseReference datab;

    Locations loc;


    //@Override
    public void onReceive(Context context, Intent intent) {
        //Toast.makeText(context, "Getting Location", Toast.LENGTH_SHORT).show();
        fusedLocationProviderClient = LocationServices.getFusedLocationProviderClient(context);

        /*fusedLocationProviderClient.getLastLocation().addOnSuccessListener(new OnSuccessListener<Location>() {
            @Override
            public void onSuccess(Location location) {
                if(location!=null){
                    latestLoc = location;
                    final String newemail = GlobalVariable.CurrentEmail.replace(".",",");
                    Date curtime = Calendar.getInstance().getTime();
                    locTime = curtime.toString();
                    databaseReference = FirebaseDatabase.getInstance().getReference();
                    databaseReference.child("Users").child(newemail).child("latitude").setValue(latestLoc.getLatitude());
                    databaseReference.child("Users").child(newemail).child("longitude").setValue(latestLoc.getLongitude());
                    databaseReference.child("Users").child(newemail).child("locTime").setValue(locTime);

                    loc.setLatitude(latestLoc.getLatitude());
                    loc.setLongtitude(latestLoc.getLongitude());
                    loc.setTime(locTime);
                    databaseReference.child("Locations").child(newemail).push().setValue(loc);

                    databaseReference = FirebaseDatabase.getInstance().getReference().child("Locations").child(newemail);
                    databaseReference.addListenerForSingleValueEvent(new ValueEventListener() {
                        @Override
                        public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                            int size = (int) dataSnapshot.getChildrenCount();
                            if(size == 11){
                                //datab = FirebaseDatabase.getInstance().getReference().child("Locations").child(newemail);
                                Query query = databaseReference.limitToFirst(1);
                                query.addListenerForSingleValueEvent(new ValueEventListener() {
                                    @Override
                                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                                        for(DataSnapshot childSnapshot : dataSnapshot.getChildren()){
                                            childSnapshot.getRef().removeValue();
                                        }
                                    }

                                    @Override
                                    public void onCancelled(@NonNull DatabaseError databaseError) {

                                    }
                                });
                            }
                        }

                        @Override
                        public void onCancelled(@NonNull DatabaseError databaseError) {

                        }
                    });


                }
            }
        });*/
    }
}

